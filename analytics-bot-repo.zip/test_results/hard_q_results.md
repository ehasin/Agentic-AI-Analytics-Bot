# Eval: Hard questions (depth=0, processing=sql)

## Q1: What is the average delivery time in days for each customer state, only for delivered orders?

**Expected:** A breakdown by state with SP included, showing average days

**Classification:** can_answer

**Status:** PASS

**Execution Plan:**
INTENT: The user wants to know the average number of days it takes to deliver orders to customers in each state, considering only orders that were successfully delivered.

QUERIES: Average delivery time in days for each customer state for delivered orders only

APPROACH: Execute a single query that calculates the mean delivery time grouped by customer state and return the results directly.

**Raw Answer:**
```
customer_state  avg_delivery_days
            SP           8.700573
            PR          11.938046
            MG          11.944953
            DF          12.899038
            SC          14.902989
            RJ          15.237004
            RS          15.248503
            GO          15.536025
            MS          15.544936
            ES          15.723810
            TO          17.598540
            MT          18.003386
            PE          18.395480
            RN          19.223629
            BA          19.278563
            RO          19.283951
            PI          19.394958
            PB          20.388781
            AC          21.000000
            CE          21.200156
            SE          21.462687
            MA          21.511855
            PA          23.725159
            AL          24.501259
            AM          26.358621
            AP          27.179104
            RR          29.341463
```

**Primary: Average delivery time in days for each customer state (delivered orders only)**
```sql
SELECT 
    c.customer_state,
    AVG(DATEDIFF('day', CAST(o.order_purchase_timestamp AS TIMESTAMP), CAST(o.order_delivered_customer_date AS TIMESTAMP))) as avg_delivery_days
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
WHERE o.order_status = 'delivered' 
    AND o.order_delivered_customer_date IS NOT NULL
GROUP BY c.customer_state
ORDER BY avg_delivery_days
```
```
customer_state  avg_delivery_days
            SP           8.700573
            PR          11.938046
            MG          11.944953
            DF          12.899038
            SC          14.902989
            RJ          15.237004
            RS          15.248503
            GO          15.536025
            MS          15.544936
            ES          15.723810
            TO          17.598540
            MT          18.003386
            PE          18.395480
            RN          19.223629
            BA          19.278563
            RO          19.283951
            PI          19.394958
            PB          20.388781
            AC          21.000000
            CE          21.200156
            SE          21.462687
            MA          21.511855
            PA          23.725159
            AL          24.501259
            AM          26.358621
            AP          27.179104
            RR          29.341463
```

**Final Answer:**
Delivery times for delivered orders vary significantly across Brazilian states, ranging from 8.7 days in São Paulo (SP) to 29.3 days in Roraima (RR). The southeastern states generally have the fastest delivery times, with São Paulo, Paraná, and Minas Gerais all receiving orders within 12 days on average, while northern states like Amazonas, Amapá, and Roraima experience delivery times exceeding 26 days.

---

## Q2: Which product category has the highest percentage of 1-star reviews?

**Expected:** A category name with a percentage or ratio

**Classification:** can_answer

**Status:** PASS

**Execution Plan:**
INTENT: The user wants to identify which product category receives the most 1-star reviews as a percentage of its total reviews.

QUERIES: Product categories ranked by percentage of 1-star reviews

APPROACH: I will calculate the percentage of 1-star reviews for each product category and identify the category with the highest percentage.

**Raw Answer:**
```
product_category_name  one_star_reviews  total_reviews  one_star_percentage
   seguros_e_servicos                 1              2                 50.0
```

**Primary: Product categories ranked by percentage of 1-star reviews**
```sql
SELECT 
    p.product_category_name,
    COUNT(CASE WHEN r.review_score = 1 THEN 1 END) as one_star_reviews,
    COUNT(r.review_score) as total_reviews,
    ROUND(100.0 * COUNT(CASE WHEN r.review_score = 1 THEN 1 END) / COUNT(r.review_score), 2) as one_star_percentage
FROM products p
JOIN order_items oi ON p.product_id = oi.product_id
JOIN orders o ON oi.order_id = o.order_id
JOIN reviews r ON o.order_id = r.order_id
WHERE p.product_category_name IS NOT NULL
    AND o.order_status != 'canceled'
GROUP BY p.product_category_name
HAVING COUNT(r.review_score) > 0
ORDER BY one_star_percentage DESC
LIMIT 1
```
```
product_category_name  one_star_reviews  total_reviews  one_star_percentage
   seguros_e_servicos                 1              2                 50.0
```

**Final Answer:**
The seguros_e_servicos (insurance and services) category has the highest percentage of 1-star reviews at 50.0%, with 1 one-star review out of 2 total reviews for that category.

---

## Q3: What is the repeat purchase rate? That is, what percentage of unique customers placed more than one order?

**Expected:** A low percentage (~3%) since most customers order once

**Classification:** can_answer

**Status:** PASS

**Execution Plan:**
INTENT: The user wants to know what percentage of unique customers are repeat purchasers by placing multiple orders.

QUERIES: Calculate the percentage of unique customers who placed more than one order

APPROACH: I will count customers with multiple orders divided by total unique customers to get the repeat purchase rate percentage.

**Raw Answer:**
```
total_unique_customers  repeat_customers  repeat_purchase_rate_percent
                  96096            2997.0                          3.12
```

**Primary: Repeat purchase rate - percentage of unique customers who placed more than one order**
```sql
WITH customer_order_counts AS (
    SELECT 
        customer_unique_id,
        COUNT(DISTINCT order_id) as order_count
    FROM customers c
    JOIN orders o ON c.customer_id = o.customer_id
    GROUP BY customer_unique_id
),
repeat_customers AS (
    SELECT 
        COUNT(*) as total_unique_customers,
        SUM(CASE WHEN order_count > 1 THEN 1 ELSE 0 END) as repeat_customers
    FROM customer_order_counts
)
SELECT 
    total_unique_customers,
    repeat_customers,
    ROUND(100.0 * repeat_customers / total_unique_customers, 2) as repeat_purchase_rate_percent
FROM repeat_customers
```
```
 total_unique_customers  repeat_customers  repeat_purchase_rate_percent
                  96096            2997.0                          3.12
```

**Final Answer:**
The repeat purchase rate for this Brazilian ecommerce marketplace is 3.12%. Out of 96,096 total unique customers, only 2,997 customers placed more than one order during the 2016-2018 period.

---

## Q4: For orders paid by credit card, what is the average number of installments and how does average order value differ by installment count?

**Expected:** A table or breakdown showing installment counts with corresponding avg order values

**Classification:** can_answer

**Status:** PASS

**Execution Plan:**
INTENT: The user wants to understand credit card payment patterns by analyzing installment usage and how order values vary with different installment options.

QUERIES: Calculate the overall average number of installments for all credit card orders, analyze how average order value changes across different installment count groupings for credit card transactions.

APPROACH: I will compute the mean installments across all credit card orders and then group orders by installment count to show average order values for each installment tier.

**Raw Answer:**
```
avg_installments
         3.507273
 payment_installments  order_count  avg_order_value
                    0            2        94.315000
                    1        25406        95.875086
                    2        12389       127.228150
                    3        10443       142.539317
                    4         7088       163.976840
                    5         5234       183.465222
                    6         3916       209.849952
                    7         1623       187.673672
                    8         4253       307.737427
                    9          644       203.440870
                   10         5316       415.015637
                   11           23       124.932174
                   12          133       321.678496
                   13           16       150.462500
                   14           15       167.962667
                   15           74       445.553108
                   16            5       292.694000
                   17            8       174.602500
                   18           27       486.483333
                   20           17       615.801765
                   21            3       243.700000
                   22            1       228.710000
                   23            1       236.480000
                   24           18       610.048889
```

**Primary: Average number of installments for credit card orders**
```sql
SELECT AVG(payment_installments) as avg_installments
FROM payments
WHERE payment_type = 'credit_card'
```
```
 avg_installments
         3.507273
```

**Primary: Average order value by installment count for credit card orders**
```sql
SELECT 
    p.payment_installments,
    COUNT(DISTINCT p.order_id) as order_count,
    AVG(p.payment_value) as avg_order_value
FROM payments p
WHERE p.payment_type = 'credit_card'
GROUP BY p.payment_installments
ORDER BY p.payment_installments
```
```
 payment_installments  order_count  avg_order_value
                    0            2        94.315000
                    1        25406        95.875086
                    2        12389       127.228150
                    3        10443       142.539317
                    4         7088       163.976840
                    5         5234       183.465222
                    6         3916       209.849952
                    7         1623       187.673672
                    8         4253       307.737427
                    9          644       203.440870
                   10         5316       415.015637
                   11           23       124.932174
                   12          133       321.678496
                   13           16       150.462500
                   14           15       167.962667
                   15           74       445.553108
                   16            5       292.694000
                   17            8       174.602500
                   18           27       486.483333
                   20           17       615.801765
                   21            3       243.700000
                   22            1       228.710000
                   23            1       236.480000
                   24           18       610.048889
```

**Final Answer:**
For credit card orders, customers choose an average of 3.5 installments. Average order value increases with installment count, rising from around 96 BRL for single payments to over 600 BRL for orders split into 20 or 24 installments, with the highest average of 615 BRL for 20-installment purchases.

---

## Q5: Which sellers have an average review score below 2.0 and more than 10 orders? List them with their city and order count.

**Expected:** A list of seller IDs with city and order count, or a statement that none qualify

**Classification:** can_answer

**Status:** PASS

**Execution Plan:**
INTENT: Find poorly performing sellers who have sufficient order volume to make their low ratings statistically meaningful.

QUERIES: Identify sellers with average review scores under 2.0 and more than 10 orders, including their location and order volume.

APPROACH: Execute a single query that filters sellers by both review score and order count criteria, then return the requested seller details directly.

**Raw Answer:**
```
seller_id    seller_city  order_count  avg_review_score
4342d4b2ba6b161468c63a7e7cfce593 rio de janeiro           19          1.263158
b1b3948701c5c72445495bd161b83a4c      sao paulo           16          1.812500
```

**Primary: Sellers with average review score below 2.0 and more than 10 orders, with city and order count**
```sql
SELECT 
    s.seller_id,
    s.seller_city,
    COUNT(DISTINCT o.order_id) as order_count,
    AVG(r.review_score) as avg_review_score
FROM sellers s
JOIN order_items oi ON s.seller_id = oi.seller_id
JOIN orders o ON oi.order_id = o.order_id
JOIN reviews r ON o.order_id = r.order_id
WHERE o.order_status != 'canceled'
GROUP BY s.seller_id, s.seller_city
HAVING COUNT(DISTINCT o.order_id) > 10 
    AND AVG(r.review_score) < 2.0
ORDER BY avg_review_score ASC, order_count DESC
```
```
                       seller_id    seller_city  order_count  avg_review_score
4342d4b2ba6b161468c63a7e7cfce593 rio de janeiro           19          1.263158
b1b3948701c5c72445495bd161b83a4c      sao paulo           16          1.812500
```

**Final Answer:**
Two sellers meet the criteria of having an average review score below 2.0 with more than 10 orders. The seller in Rio de Janeiro has 19 orders with an average review score of 1.26, while the seller in São Paulo has 16 orders with an average review score of 1.81.

---

## Q6: What is the month-over-month order growth rate for 2017?

**Expected:** Monthly growth rates as percentages for 2017

**Classification:** can_answer

**Status:** PASS

**Execution Plan:**
INTENT: The user wants to know the month-over-month growth rate of orders throughout 2017.

QUERIES: Monthly order counts for 2017 with calculated month-over-month growth rates

APPROACH: I will calculate the percentage change in order volume between consecutive months in 2017 and present the growth rates for each month.

**Raw Answer:**
```
year  month  order_count  prev_month_orders  mom_growth_rate_percent
 2017      1          800               <NA>                      NaN
 2017      2         1780                800                   122.50
 2017      3         2682               1780                    50.67
 2017      4         2404               2682                   -10.37
 2017      5         3700               2404                    53.91
 2017      6         3245               3700                   -12.30
 2017      7         4026               3245                    24.07
 2017      8         4331               4026                     7.58
 2017      9         4285               4331                    -1.06
 2017     10         4631               4285                     8.07
 2017     11         7544               4631                    62.90
 2017     12         5673               7544                   -24.80
```

**Primary: Monthly order counts for 2017 with month-over-month growth rates**
```sql
WITH monthly_orders AS (
  SELECT 
    DATE_PART('year', CAST(order_purchase_timestamp AS TIMESTAMP)) AS year,
    DATE_PART('month', CAST(order_purchase_timestamp AS TIMESTAMP)) AS month,
    COUNT(*) AS order_count
  FROM orders
  WHERE DATE_PART('year', CAST(order_purchase_timestamp AS TIMESTAMP)) = 2017
  GROUP BY DATE_PART('year', CAST(order_purchase_timestamp AS TIMESTAMP)), DATE_PART('month', CAST(order_purchase_timestamp AS TIMESTAMP))
),
monthly_growth AS (
  SELECT 
    year,
    month,
    order_count,
    LAG(order_count) OVER (ORDER BY year, month) AS prev_month_orders,
    CASE 
      WHEN LAG(order_count) OVER (ORDER BY year, month) IS NOT NULL 
      THEN ROUND(((order_count - LAG(order_count) OVER (ORDER BY year, month)) * 100.0 / LAG(order_count) OVER (ORDER BY year, month)), 2)
      ELSE NULL 
    END AS mom_growth_rate_percent
  FROM monthly_orders
)
SELECT 
  year,
  month,
  order_count,
  prev_month_orders,
  mom_growth_rate_percent
FROM monthly_growth
ORDER BY year, month
```
```
 year  month  order_count  prev_month_orders  mom_growth_rate_percent
 2017      1          800               <NA>                      NaN
 2017      2         1780                800                   122.50
 2017      3         2682               1780                    50.67
 2017      4         2404               2682                   -10.37
 2017      5         3700               2404                    53.91
 2017      6         3245               3700                   -12.30
 2017      7         4026               3245                    24.07
 2017      8         4331               4026                     7.58
 2017      9         4285               4331                    -1.06
 2017     10         4631               4285                     8.07
 2017     11         7544               4631                    62.90
 2017     12         5673               7544                   -24.80
```

**Final Answer:**
The Olist Brazilian marketplace experienced highly variable month-over-month order growth throughout 2017, ranging from a peak increase of 122.50% in February (jumping from 800 to 1,780 orders) to the steepest decline of -24.80% in December (dropping from 7,544 to 5,673 orders). Notable growth spikes occurred in February (+122.50%), March (+50.67%), May (+53.91%), and November (+62.90%), while the most significant contractions happened in April (-10.37%), June (-12.30%), and December (-24.80%).

---

## Q7: Is there a correlation between product weight and freight cost? What is the Pearson correlation coefficient?

**Expected:** A correlation coefficient between 0 and 1

**Classification:** can_answer

**Status:** PASS

**Execution Plan:**
INTENT: The user wants to determine if there is a statistical relationship between product weight and freight cost by calculating the Pearson correlation coefficient.

QUERIES: Calculate the Pearson correlation coefficient between product weight and freight cost to measure the strength and direction of their linear relationship.

APPROACH: I will compute the Pearson correlation coefficient directly and report the numerical value along with interpretation of whether a correlation exists.

**Raw Answer:**
```
pearson_correlation_coefficient  sample_size  avg_weight_g  avg_freight_brl
                        0.603727       112241   2095.751802        20.100919
```

**Primary: Pearson correlation coefficient between product weight and freight cost**
```sql
SELECT 
    CORR(p.product_weight_g, oi.freight_value) as pearson_correlation_coefficient,
    COUNT(*) as sample_size,
    AVG(p.product_weight_g) as avg_weight_g,
    AVG(oi.freight_value) as avg_freight_brl
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
WHERE p.product_weight_g IS NOT NULL 
    AND oi.freight_value IS NOT NULL
    AND p.product_weight_g > 0
    AND oi.freight_value > 0
```
```
 pearson_correlation_coefficient  sample_size  avg_weight_g  avg_freight_brl
                        0.603727       112241   2095.751802        20.100919
```

**Final Answer:**
There is a moderate positive correlation between product weight and freight cost, with a Pearson correlation coefficient of 0.604 based on 112,241 products. Products in the dataset averaged 2,096 grams in weight with an average freight cost of 20.10 BRL.

---

## Q8: What are the top 5 seller-customer state pairs by order volume? For example, seller in SP shipping to RJ.

**Expected:** Pairs like SP->SP, SP->RJ etc. with counts

**Classification:** can_answer

**Status:** PASS

**Execution Plan:**
INTENT: The user wants to identify the top 5 combinations of seller state and customer state based on total number of orders.

QUERIES: Top 5 seller-customer state pairs by order volume

APPROACH: Will directly return the top 5 state pairs ranked by total order count from the query results.

**Raw Answer:**
```
seller_state customer_state  order_count
          SP             SP        31294
          SP             RJ         8421
          SP             MG         7566
          SP             RS         3661
          SP             PR         3167
```

**Primary: Top 5 seller-customer state pairs by order volume**
```sql
SELECT 
    s.seller_state,
    c.customer_state,
    COUNT(DISTINCT o.order_id) as order_count
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN sellers s ON oi.seller_id = s.seller_id
JOIN customers c ON o.customer_id = c.customer_id
WHERE o.order_status != 'canceled'
GROUP BY s.seller_state, c.customer_state
ORDER BY order_count DESC
LIMIT 5
```
```
seller_state customer_state  order_count
          SP             SP        31294
          SP             RJ         8421
          SP             MG         7566
          SP             RS         3661
          SP             PR         3167
```

**Final Answer:**
The top seller-customer state pair by order volume is São Paulo (SP) sellers shipping to São Paulo (SP) customers with 31,294 orders. The next four highest-volume pairs all involve São Paulo sellers shipping to other states: 8,421 orders to Rio de Janeiro (RJ), 7,566 orders to Minas Gerais (MG), 3,661 orders to Rio Grande do Sul (RS), and 3,167 orders to Paraná (PR).

---

## Q9: What is the average profit margin per category, assuming COGS is 60% of the item price?

**Expected:** Declines (no real COGS data), the question leads to meaningless analysis.

**Classification:** clarifications_needed

**Status:** PASS

**Raw Answer:**
```
The question is unclear. Assuming COGS is exactly 60% of item price would result in identical profit margins (40%) across all categories, making the analysis trivially uniform. Consider asking "What is the average revenue or markup per category?" or specify how COGS might vary by category to enable meaningful comparison.
```

**Final Answer:**
The question is unclear. Assuming COGS is exactly 60% of item price would result in identical profit margins (40%) across all categories, making the analysis trivially uniform. Consider asking "What is the average revenue or markup per category?" or specify how COGS might vary by category to enable meaningful comparison.

---

## Q10: Compare the delivery performance of the top 3 carriers by volume: what percentage of their orders arrived late?

**Expected:** Should decline: the dataset has no carrier information

**Classification:** cant_answer

**Status:** PASS

**Raw Answer:**
```
Can't answer based on the available data. (missing_data - The data model does not contain carrier information. While delivery performance can be calculated using orders.order_delivered_customer_date vs orders.order_estimated_delivery_date to determine late deliveries, there is no carrier/shipping company identifier in any table. The available delivery-related columns are order_delivered_carrier_date (when seller handed to carrier) and order_delivered_customer_date (final delivery), but no field identifies which specific carrier handled each shipment.)
```

**Final Answer:**
Can't answer based on the available data. (missing_data - The data model does not contain carrier information. While delivery performance can be calculated using orders.order_delivered_customer_date vs orders.order_estimated_delivery_date to determine late deliveries, there is no carrier/shipping company identifier in any table. The available delivery-related columns are order_delivered_carrier_date (when seller handed to carrier) and order_delivered_customer_date (final delivery), but no field identifies which specific carrier handled each shipment.)

---


## Summary: 10/10 passed
