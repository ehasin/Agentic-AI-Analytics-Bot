# Eval: Multi-stage questions (depth=0, processing=sql)

## Q1: First, classify products into 'small', 'medium', and 'bulky' based on the 33rd and 66th percentiles of product_weight_g. Then show total revenue and average review score for each size class.

**Expected:** Three size classes with revenue and avg review score for each

**Classification:** can_answer

**Status:** PASS

**Execution Plan:**
INTENT: The user wants to categorize products by size based on weight percentiles and analyze revenue and review performance for each category.

QUERIES: Calculate 33rd and 66th percentiles of product weight, classify products into small/medium/bulky categories, compute total revenue and average review score for each size class.

APPROACH: Products will be segmented into three weight-based categories using percentile thresholds, then aggregated metrics will be calculated and presented for each size class.

**Raw Answer:**
```
size_class  total_revenue  average_review_score
     small     3488174.18              4.055675
    medium     4348855.50              4.071017
     bulky     7974224.05              4.008240
```

**Primary: Calculate size class percentiles and classify products with revenue and review scores**
```sql
WITH percentiles AS (
  SELECT 
    PERCENTILE_CONT(0.33) WITHIN GROUP (ORDER BY product_weight_g) AS p33,
    PERCENTILE_CONT(0.66) WITHIN GROUP (ORDER BY product_weight_g) AS p66
  FROM products
  WHERE product_weight_g IS NOT NULL
),
product_classification AS (
  SELECT 
    p.product_id,
    p.product_weight_g,
    CASE 
      WHEN p.product_weight_g <= perc.p33 THEN 'small'
      WHEN p.product_weight_g <= perc.p66 THEN 'medium'
      ELSE 'bulky'
    END AS size_class
  FROM products p
  CROSS JOIN percentiles perc
  WHERE p.product_weight_g IS NOT NULL
)
SELECT 
  pc.size_class,
  SUM(oi.price + oi.freight_value) AS total_revenue,
  AVG(r.review_score) AS average_review_score
FROM product_classification pc
JOIN order_items oi ON pc.product_id = oi.product_id
JOIN orders o ON oi.order_id = o.order_id
LEFT JOIN reviews r ON o.order_id = r.order_id
WHERE o.order_status != 'canceled'
GROUP BY pc.size_class
ORDER BY 
  CASE 
    WHEN pc.size_class = 'small' THEN 1
    WHEN pc.size_class = 'medium' THEN 2
    WHEN pc.size_class = 'bulky' THEN 3
  END
```
```
size_class  total_revenue  average_review_score
     small     3488174.18              4.055675
    medium     4348855.50              4.071017
     bulky     7974224.05              4.008240
```

**Final Answer:**
Products were classified into three size categories based on weight percentiles, with small products generating 3,488,174 in total revenue and an average review score of 4.06. Medium-sized products produced 4,348,856 in revenue with a 4.07 average review score, while bulky products generated the highest revenue at 7,974,224 but had a slightly lower average review score of 4.01.

---

## Q2: Find the month with the highest total revenue. Then identify the top 3 product categories in that month. Finally, show how those same 3 categories performed in every other month of the same year — were they consistently top sellers or just spiking in that one month?

**Expected:** A month identified, top 3 categories named, then a monthly breakdown of those categories across the year

**Classification:** can_answer

**Status:** PASS

**Execution Plan:**
INTENT: The user wants to identify the peak revenue month, find its top 3 product categories, and analyze whether those categories were consistently high performers throughout the year or just had a one-time spike.

QUERIES: Find the month with highest total revenue and identify top 3 product categories in that month, Show how the top 3 categories from peak month performed across all months of the same year

APPROACH: I will first identify the peak revenue month and its top 3 categories, then track those same categories' performance across all months to determine if they were consistent top performers or experienced isolated success.

**Raw Answer:**
```
peak_year  peak_month  peak_month_revenue       top_category  category_revenue_in_peak_month
      2017          11          1173387.01    cama_mesa_banho                       106395.47
      2017          11          1173387.01 relogios_presentes                       104495.45
      2017          11          1173387.01       beleza_saude                        89575.16
 year  month product_category_name  monthly_category_revenue  category_rank_in_month
 2017      1          beleza_saude                  14039.74                       1
 2017      2          beleza_saude                  26130.08                       1
 2017      3          beleza_saude                  29770.32                       2
 2017      4          beleza_saude                  26227.84                       2
 2017      5          beleza_saude                  52801.02                       1
 2017      6          beleza_saude                  37211.48                       2
 2017      7          beleza_saude                  40276.47                       2
 2017      8          beleza_saude                  56191.40                       2
 2017      9          beleza_saude                  59101.68                       2
 2017     10          beleza_saude                  48782.32                       3
 2017     11          beleza_saude                  89575.16                       3
 2017     12          beleza_saude                  69602.82                       2
 2017      1       cama_mesa_banho                   4817.27                       3
 2017      2       cama_mesa_banho                  19186.07                       2
 2017      3       cama_mesa_banho                  30650.01                       1
 2017      4       cama_mesa_banho                  29007.36                       1
 2017      5       cama_mesa_banho                  39662.14                       3
 2017      6       cama_mesa_banho                  41684.51                       1
 2017      7       cama_mesa_banho                  74560.35                       1
 2017      8       cama_mesa_banho                  66212.90                       1
 2017      9       cama_mesa_banho                  62177.20                       1
 2017     10       cama_mesa_banho                  55448.85                       2
 2017     11       cama_mesa_banho                 106395.47                       1
 2017     12       cama_mesa_banho                  59896.26                       3
 2017      1    relogios_presentes                   8310.83                       2
 2017      2    relogios_presentes                  12370.67                       3
 2017      3    relogios_presentes                  26248.32                       3
 2017      4    relogios_presentes                  25108.84                       3
 2017      5    relogios_presentes                  40194.45                       2
 2017      6    relogios_presentes                  30367.42                       3
 2017      7    relogios_presentes                  38362.70                       3
 2017      8    relogios_presentes                  39578.95                       3
 2017      9    relogios_presentes                  51283.89                       3
 2017     10    relogios_presentes                  70012.91                       1
 2017     11    relogios_presentes                 104495.45                       2
 2017     12    relogios_presentes                  77152.97                       1
```

**Primary: Find the month with highest total revenue and identify top 3 product categories in that month**
```sql
WITH monthly_revenue AS (
  SELECT 
    DATE_PART('year', CAST(o.order_purchase_timestamp AS TIMESTAMP)) as year,
    DATE_PART('month', CAST(o.order_purchase_timestamp AS TIMESTAMP)) as month,
    SUM(oi.price + oi.freight_value) as total_revenue
  FROM orders o
  JOIN order_items oi ON o.order_id = oi.order_id
  WHERE o.order_status != 'canceled'
  GROUP BY DATE_PART('year', CAST(o.order_purchase_timestamp AS TIMESTAMP)), 
           DATE_PART('month', CAST(o.order_purchase_timestamp AS TIMESTAMP))
),
highest_revenue_month AS (
  SELECT year, month, total_revenue
  FROM monthly_revenue
  ORDER BY total_revenue DESC
  LIMIT 1
),
top_categories_in_peak_month AS (
  SELECT 
    p.product_category_name,
    SUM(oi.price + oi.freight_value) as category_revenue
  FROM orders o
  JOIN order_items oi ON o.order_id = oi.order_id
  JOIN products p ON oi.product_id = p.product_id
  CROSS JOIN highest_revenue_month hrm
  WHERE o.order_status != 'canceled'
    AND DATE_PART('year', CAST(o.order_purchase_timestamp AS TIMESTAMP)) = hrm.year
    AND DATE_PART('month', CAST(o.order_purchase_timestamp AS TIMESTAMP)) = hrm.month
    AND p.product_category_name IS NOT NULL
  GROUP BY p.product_category_name
  ORDER BY category_revenue DESC
  LIMIT 3
)
SELECT 
  hrm.year as peak_year,
  hrm.month as peak_month,
  hrm.total_revenue as peak_month_revenue,
  tc.product_category_name as top_category,
  tc.category_revenue as category_revenue_in_peak_month
FROM highest_revenue_month hrm
CROSS JOIN top_categories_in_peak_month tc
ORDER BY tc.category_revenue DESC
```
```
 peak_year  peak_month  peak_month_revenue       top_category  category_revenue_in_peak_month
      2017          11          1173387.01    cama_mesa_banho                       106395.47
      2017          11          1173387.01 relogios_presentes                       104495.45
      2017          11          1173387.01       beleza_saude                        89575.16
```

**Primary: Show how the top 3 categories from peak month performed across all months of the same year**
```sql
WITH monthly_revenue AS (
  SELECT 
    DATE_PART('year', CAST(o.order_purchase_timestamp AS TIMESTAMP)) as year,
    DATE_PART('month', CAST(o.order_purchase_timestamp AS TIMESTAMP)) as month,
    SUM(oi.price + oi.freight_value) as total_revenue
  FROM orders o
  JOIN order_items oi ON o.order_id = oi.order_id
  WHERE o.order_status != 'canceled'
  GROUP BY DATE_PART('year', CAST(o.order_purchase_timestamp AS TIMESTAMP)), 
           DATE_PART('month', CAST(o.order_purchase_timestamp AS TIMESTAMP))
),
highest_revenue_month AS (
  SELECT year, month, total_revenue
  FROM monthly_revenue
  ORDER BY total_revenue DESC
  LIMIT 1
),
top_categories_in_peak_month AS (
  SELECT 
    p.product_category_name
  FROM orders o
  JOIN order_items oi ON o.order_id = oi.order_id
  JOIN products p ON oi.product_id = p.product_id
  CROSS JOIN highest_revenue_month hrm
  WHERE o.order_status != 'canceled'
    AND DATE_PART('year', CAST(o.order_purchase_timestamp AS TIMESTAMP)) = hrm.year
    AND DATE_PART('month', CAST(o.order_purchase_timestamp AS TIMESTAMP)) = hrm.month
    AND p.product_category_name IS NOT NULL
  GROUP BY p.product_category_name
  ORDER BY SUM(oi.price + oi.freight_value) DESC
  LIMIT 3
)
SELECT 
  hrm.year,
  DATE_PART('month', CAST(o.order_purchase_timestamp AS TIMESTAMP)) as month,
  tc.product_category_name,
  SUM(oi.price + oi.freight_value) as monthly_category_revenue,
  RANK() OVER (
    PARTITION BY DATE_PART('month', CAST(o.order_purchase_timestamp AS TIMESTAMP)) 
    ORDER BY SUM(oi.price + oi.freight_value) DESC
  ) as category_rank_in_month
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
CROSS JOIN highest_revenue_month hrm
JOIN top_categories_in_peak_month tc ON p.product_category_name = tc.product_category_name
WHERE o.order_status != 'canceled'
  AND DATE_PART('year', CAST(o.order_purchase_timestamp AS TIMESTAMP)) = hrm.year
GROUP BY hrm.year, 
         DATE_PART('month', CAST(o.order_purchase_timestamp AS TIMESTAMP)),
         tc.product_category_name
ORDER BY tc.product_category_name, month
```
```
 year  month product_category_name  monthly_category_revenue  category_rank_in_month
 2017      1          beleza_saude                  14039.74                       1
 2017      2          beleza_saude                  26130.08                       1
 2017      3          beleza_saude                  29770.32                       2
 2017      4          beleza_saude                  26227.84                       2
 2017      5          beleza_saude                  52801.02                       1
 2017      6          beleza_saude                  37211.48                       2
 2017      7          beleza_saude                  40276.47                       2
 2017      8          beleza_saude                  56191.40                       2
 2017      9          beleza_saude                  59101.68                       2
 2017     10          beleza_saude                  48782.32                       3
 2017     11          beleza_saude                  89575.16                       3
 2017     12          beleza_saude                  69602.82                       2
 2017      1       cama_mesa_banho                   4817.27                       3
 2017      2       cama_mesa_banho                  19186.07                       2
 2017      3       cama_mesa_banho                  30650.01                       1
 2017      4       cama_mesa_banho                  29007.36                       1
 2017      5       cama_mesa_banho                  39662.14                       3
 2017      6       cama_mesa_banho                  41684.51                       1
 2017      7       cama_mesa_banho                  74560.35                       1
 2017      8       cama_mesa_banho                  66212.90                       1
 2017      9       cama_mesa_banho                  62177.20                       1
 2017     10       cama_mesa_banho                  55448.85                       2
 2017     11       cama_mesa_banho                 106395.47                       1
 2017     12       cama_mesa_banho                  59896.26                       3
 2017      1    relogios_presentes                   8310.83                       2
 2017      2    relogios_presentes                  12370.67                       3
 2017      3    relogios_presentes                  26248.32                       3
 2017      4    relogios_presentes                  25108.84                       3
 2017      5    relogios_presentes                  40194.45                       2
 2017      6    relogios_presentes                  30367.42                       3
 2017      7    relogios_presentes                  38362.70                       3
 2017      8    relogios_presentes                  39578.95                       3
 2017      9    relogios_presentes                  51283.89                       3
 2017     10    relogios_presentes                  70012.91                       1
 2017     11    relogios_presentes                 104495.45                       2
 2017     12    relogios_presentes                  77152.97                       1
```

**Final Answer:**
November 2017 was the highest revenue month with 1,173,387 in total sales, led by three top categories: cama_mesa_banho (bed/table/bath items) at 106,395, relogios_presentes (watches/gifts) at 104,495, and beleza_saude (health/beauty) at 89,575.

These three categories were consistently strong performers throughout 2017, with each ranking in the top 3 for revenue in every single month of the year. Cama_mesa_banho claimed the #1 spot in 7 out of 12 months, relogios_presentes topped the rankings in 2 months, and beleza_saude led in 2 months, demonstrating they were sustained top sellers rather than just experiencing a November spike.

---

## Q3: Segment customers into 'one-time' and 'repeat' based on whether customer_unique_id appears in more than one order. Then compare these two segments on: average order value, average review score, and average delivery time in days.

**Expected:** Two segments with three metrics compared side by side

**Classification:** can_answer

**Status:** PASS

**Execution Plan:**
INTENT: The user wants to segment customers by purchase frequency and compare key business metrics between one-time and repeat customers.

QUERIES: Customer segmentation based on order frequency with calculation of average order value, average review score, and average delivery time for each segment

APPROACH: I will count orders per customer to create segments, then calculate and compare the three metrics between one-time and repeat customer groups.

**Raw Answer:**
```
customer_segment  customer_count  avg_order_value  avg_review_score  avg_delivery_days
        one-time           90446       160.893016          4.152529          12.513634
          repeat            2912       156.204523          4.211148          12.245192
```

**Primary: Customer segmentation with order metrics comparison**
```sql
WITH customer_segments AS (
  SELECT 
    c.customer_unique_id,
    COUNT(DISTINCT o.order_id) as order_count,
    CASE 
      WHEN COUNT(DISTINCT o.order_id) = 1 THEN 'one-time'
      ELSE 'repeat'
    END as customer_segment
  FROM customers c
  JOIN orders o ON c.customer_id = o.customer_id
  WHERE o.order_status != 'canceled'
  GROUP BY c.customer_unique_id
),
order_metrics AS (
  SELECT 
    c.customer_unique_id,
    o.order_id,
    SUM(oi.price + oi.freight_value) as order_value,
    AVG(r.review_score) as order_review_score,
    DATEDIFF('day', CAST(o.order_purchase_timestamp AS TIMESTAMP), CAST(o.order_delivered_customer_date AS TIMESTAMP)) as delivery_days
  FROM customers c
  JOIN orders o ON c.customer_id = o.customer_id
  JOIN order_items oi ON o.order_id = oi.order_id
  LEFT JOIN reviews r ON o.order_id = r.order_id
  WHERE o.order_status = 'delivered'
  GROUP BY c.customer_unique_id, o.order_id, o.order_purchase_timestamp, o.order_delivered_customer_date
)
SELECT 
  cs.customer_segment,
  COUNT(DISTINCT cs.customer_unique_id) as customer_count,
  AVG(om.order_value) as avg_order_value,
  AVG(om.order_review_score) as avg_review_score,
  AVG(om.delivery_days) as avg_delivery_days
FROM customer_segments cs
JOIN order_metrics om ON cs.customer_unique_id = om.customer_unique_id
GROUP BY cs.customer_segment
ORDER BY cs.customer_segment
```
```
customer_segment  customer_count  avg_order_value  avg_review_score  avg_delivery_days
        one-time           90446       160.893016          4.152529          12.513634
          repeat            2912       156.204523          4.211148          12.245192
```

**Final Answer:**
The analysis segments 93,358 customers into 90,446 one-time buyers and 2,912 repeat customers, revealing that 97% of customers make only a single purchase. One-time customers have a slightly higher average order value of $160.89 compared to $156.20 for repeat customers, while repeat customers show marginally better satisfaction with an average review score of 4.21 versus 4.15 and faster delivery times of 12.2 days versus 12.5 days.

---

## Q4: Rank sellers into 'high volume' (top 10% by order count), 'medium volume' (next 40%), and 'low volume' (bottom 50%). Then calculate the percentage of late deliveries for each seller tier.

**Expected:** Three seller tiers with late delivery percentages

**Classification:** can_answer

**Status:** PASS

**Execution Plan:**
INTENT: The user wants to segment sellers by order volume into three tiers and analyze late delivery performance for each tier.

QUERIES: Rank all sellers by total order count, assign volume tier labels based on percentile thresholds (top 10%, next 40%, bottom 50%), calculate late delivery percentage for each seller tier

APPROACH: Results will be grouped by the three volume tiers to show late delivery percentages as key performance metrics for high, medium, and low volume seller segments.

**Raw Answer:**
```
seller_tier  sellers_in_tier  total_orders  total_late_orders  late_delivery_percentage
  high volume              309       67183.0             5414.0                      8.06
medium volume             1228       26997.0             2124.0                      7.87
   low volume             1433        3631.0              306.0                      8.43
```

**Primary: Rank sellers into volume tiers and calculate late delivery percentages by tier**
```sql
WITH seller_order_counts AS (
  SELECT 
    s.seller_id,
    COUNT(DISTINCT oi.order_id) as order_count
  FROM sellers s
  JOIN order_items oi ON s.seller_id = oi.seller_id
  JOIN orders o ON oi.order_id = o.order_id
  WHERE o.order_status != 'canceled'
  GROUP BY s.seller_id
),
seller_percentiles AS (
  SELECT 
    seller_id,
    order_count,
    PERCENT_RANK() OVER (ORDER BY order_count DESC) as percentile_rank
  FROM seller_order_counts
),
seller_tiers AS (
  SELECT 
    seller_id,
    order_count,
    CASE 
      WHEN percentile_rank <= 0.10 THEN 'high volume'
      WHEN percentile_rank <= 0.50 THEN 'medium volume' 
      ELSE 'low volume'
    END as seller_tier
  FROM seller_percentiles
),
seller_delivery_performance AS (
  SELECT 
    st.seller_id,
    st.seller_tier,
    COUNT(DISTINCT o.order_id) as total_delivered_orders,
    COUNT(DISTINCT CASE 
      WHEN CAST(o.order_delivered_customer_date AS TIMESTAMP) > CAST(o.order_estimated_delivery_date AS TIMESTAMP) 
      THEN o.order_id 
    END) as late_orders
  FROM seller_tiers st
  JOIN order_items oi ON st.seller_id = oi.seller_id
  JOIN orders o ON oi.order_id = o.order_id
  WHERE o.order_status = 'delivered'
    AND o.order_delivered_customer_date IS NOT NULL
    AND o.order_estimated_delivery_date IS NOT NULL
  GROUP BY st.seller_id, st.seller_tier
)
SELECT 
  seller_tier,
  COUNT(DISTINCT seller_id) as sellers_in_tier,
  SUM(total_delivered_orders) as total_orders,
  SUM(late_orders) as total_late_orders,
  ROUND(100.0 * SUM(late_orders) / SUM(total_delivered_orders), 2) as late_delivery_percentage
FROM seller_delivery_performance
GROUP BY seller_tier
ORDER BY 
  CASE seller_tier 
    WHEN 'high volume' THEN 1
    WHEN 'medium volume' THEN 2 
    WHEN 'low volume' THEN 3
  END
```
```
  seller_tier  sellers_in_tier  total_orders  total_late_orders  late_delivery_percentage
  high volume              309       67183.0             5414.0                      8.06
medium volume             1228       26997.0             2124.0                      7.87
   low volume             1433        3631.0              306.0                      8.43
```

**Final Answer:**
Sellers were categorized into three volume tiers: 309 high-volume sellers (top 10%) processed 67,183 orders, 1,228 medium-volume sellers (next 40%) handled 26,997 orders, and 1,433 low-volume sellers (bottom 50%) fulfilled 3,631 orders. Late delivery rates are remarkably consistent across all tiers, with high-volume sellers at 8.06%, medium-volume at 7.87%, and low-volume at 8.43%.

---

## Q5: Classify orders as 'same state' or 'cross state' based on whether the seller state matches the customer state. Then compare average delivery time, average freight cost, and average review score between the two groups.

**Expected:** Two groups with delivery time, freight cost, and review score compared

**Classification:** can_answer

**Status:** PASS

**Execution Plan:**
INTENT: The user wants to analyze how shipping within the same state versus across state boundaries affects delivery performance metrics and customer satisfaction.

QUERIES: Compare delivery time, freight cost, and review scores between same-state and cross-state orders by classifying orders based on seller-customer state matching and calculating average metrics for each group.

APPROACH: Orders will be classified into same-state or cross-state categories, then average delivery time, freight cost, and review scores will be calculated and compared between the two groups to identify performance differences.

**Raw Answer:**
```
order_classification  avg_delivery_days  avg_freight_cost  avg_review_score  total_orders
          same state           7.866381         13.484034          4.197399         40084
         cross state          14.992551         23.659964          4.015375         70748
```

**Primary: Compare delivery time, freight cost, and review scores between same-state and cross-state orders**
```sql
WITH order_classification AS (
    SELECT 
        o.order_id,
        CASE 
            WHEN c.customer_state = s.seller_state THEN 'same state'
            ELSE 'cross state'
        END AS order_classification,
        DATEDIFF('day', CAST(o.order_purchase_timestamp AS TIMESTAMP), CAST(o.order_delivered_customer_date AS TIMESTAMP)) AS delivery_days,
        oi.freight_value,
        r.review_score
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    JOIN customers c ON o.customer_id = c.customer_id
    JOIN sellers s ON oi.seller_id = s.seller_id
    LEFT JOIN reviews r ON o.order_id = r.order_id
    WHERE o.order_status = 'delivered'
        AND o.order_delivered_customer_date IS NOT NULL
)
SELECT 
    order_classification,
    AVG(delivery_days) AS avg_delivery_days,
    AVG(freight_value) AS avg_freight_cost,
    AVG(review_score) AS avg_review_score,
    COUNT(*) AS total_orders
FROM order_classification
GROUP BY order_classification
```
```
order_classification  avg_delivery_days  avg_freight_cost  avg_review_score  total_orders
          same state           7.866381         13.484034          4.197399         40084
         cross state          14.992551         23.659964          4.015375         70748
```

**Final Answer:**
Cross-state orders take significantly longer to deliver (15.0 days on average) compared to same-state orders (7.9 days), nearly doubling the delivery time. Freight costs are also substantially higher for cross-state shipments at 23.66 versus 13.48 for same-state orders. Same-state orders achieve slightly better customer satisfaction with an average review score of 4.20 compared to 4.02 for cross-state orders, with cross-state orders representing the majority at 70,748 total orders versus 40,084 same-state orders.

---


## Summary: 5/5 passed
